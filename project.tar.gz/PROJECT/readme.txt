Execute vah.sh script

Then you can use the following commands:

ditiss	--> For setting up pre-requisite of server then client and then selecting TOOL 
to install and setup

ditiss-client --> For client side pre-requisites

ditiss-server --> For server side pre-requisites

